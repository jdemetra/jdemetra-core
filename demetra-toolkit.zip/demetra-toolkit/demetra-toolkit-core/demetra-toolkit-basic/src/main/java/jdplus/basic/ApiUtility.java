/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdplus.basic;

import demetra.data.DoubleSeq;
import jdplus.linearmodel.LinearModel;
import jdplus.math.matrices.Matrix;

/**
 *
 * @author palatej
 */
@lombok.experimental.UtilityClass
public class ApiUtility {
//    public demetra.linearmodel.LinearModel toApi(LinearModel model){
//        return new demetra.linearmodel.LinearModel(model.getY().toArray(), model.isMeanCorrection(),model.getX().unmodifiable());
//    }
//    
//    public LinearModel fromApi(demetra.linearmodel.LinearModel model){
//        return LinearModel.builder()
//                .y(DoubleSeq.of(model.getY()))
//                .meanCorrection(model.isMeanCorrection())
//                .addX(Matrix.of(model.getX()))
//                .build();
//    }
}
